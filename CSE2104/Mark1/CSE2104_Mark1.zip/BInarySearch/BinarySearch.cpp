#include<bits/stdc++.h>
using namespace std;

int binary_src(int arr[],int x,int siz){
    int lw,hi,mid;
    lw=0;
    hi=siz-1;
    while(lw<=hi){
        mid=(lw+hi)/2;
        if(x==arr[mid]){
            return mid;
        }
        else if(arr[mid]>x)                     ///In desenting order just swap((hi=mid-1),(lw=mid+1)) in if else condition
            hi=mid-1;
            //lw=mid+1;
        else
            lw=mid+1;
            //hi=mid-1
    }

    return -1;

}
int lower_bound(int arr[], int N, int X)
{
    int mid;

    // Initialise starting index and
    // ending index
    int low = 0;
    int high = N;

    // Till low is less than high
    while (low < high) {
        mid = low + (high - low) / 2;

        // If X is less than or equal
        // to arr[mid], then find in
        // left subarray
        if (X <= arr[mid]) {
            high = mid;
        }

        // If X is greater arr[mid]
        // then find in right subarray
        else {
            low = mid + 1;
        }
    }

    // if X is greater than arr[n-1]
    if(low < N && arr[low] < X) {
       low++;
    }

    // Return the lower_bound index
    return low;
}

// Function to implement upper_bound
int upper_bound(int arr[], int N, int X)
{
    int mid;

    // Initialise starting index and
    // ending index
    int low = 0;
    int high = N;

    // Till low is less than high
    while (low < high) {
        // Find the middle index
        mid = low + (high - low) / 2;

        // If X is greater than or equal
        // to arr[mid] then find
        // in right subarray
        if (X >= arr[mid]) {
            low = mid + 1;
        }

        // If X is less than arr[mid]
        // then find in left subarray
        else {
            high = mid;
        }
    }

    // if X is greater than arr[n-1]
    if(low < N && arr[low] <= X) {
       low++;
    }

    // Return the upper_bound index
    return low;
}

void write(int n){
    if(n!=-1)
        cout<<"Index Found : "<<n<<endl;
    else{
        cout<<"NOT FOUND"<<endl;
    }

}

int main(){
    int arr[]={1,2,3,4,5,6,7,8,9};
    int siz=sizeof(arr)/sizeof(arr[0]);
    int res=binary_src(arr,9,siz);
    write(res);

}
