/*lock a number cheack its left side
 if any number >  then right shift all number.
 then insert lock number at the end of left shift numbers
 */


#include <bits/stdc++.h>
using namespace std;
void printArray(int arr[], int n);

void insertionSort(int arr[], int siz)
{
    for(int i=1;i<siz;i++){
        int key=arr[i];
        int j=i-1;
        while(j>=0&&arr[j]>key){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;

    }
}
void write(int arr[],int siz){

    FILE *fs=fopen("output.txt","w+");
    fprintf(fs,"New Array After Selection Sort \n");
    for(int i=0;i<siz;i++)
        fprintf(fs,"%d ",arr[i]);
    fprintf(fs,"\n");

    fclose(fs); //file must be close after read and wirte

}

int main()
{
    int arr[] = { 1,3,2,7,5,6,9,10,8,4};
    int n = sizeof(arr) / sizeof(arr[0]);

    insertionSort(arr, n);
    write(arr,n);

    return 0;
}
