#include<bits/stdc++.h>
using namespace std;

int main(){
    FILE *fs = fopen("output.txt","w+");
    time_t start_t,end_t;          // time_t is a data type
    double dif;
    start_t=clock();               // clock function return number of clock ticks

    //block of code

    end_t=clock();

    dif=(end_t-start_t);

    double cpu_t=dif/CLOCKS_PER_SEC;         // CLOCKS_PER_SEC is a builtin constant value depend of different os and cpu performence

    fprintf(fs,"Total CPU Time: %lf \n",cpu_t);
    fclose(fs);                                  //file must be close after read and wirte
    return 0;


}

