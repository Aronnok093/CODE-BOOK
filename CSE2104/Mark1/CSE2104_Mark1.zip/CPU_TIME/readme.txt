﻿CPU time is not wall time (as in a clock on the wall). 

CPU time is the total execution time or run time for which the CPU was dedicated to a process. 

The CPU must service many processes every second, not just yours, so your process only gets small task slices in between processing other requests. Each of those small task slices is counted toward the total execution time. However, the time in between processing your requests, while the CPU is processing someone else request, is NOT counted towards your CPU time.

For example, let's run gzip on a 20MB Apache log file and see where the processing time went:
$ time gzip accessible
real -> 0m2.125s
user -> 0m1.920s
sys -> 0m0.170s

This process took 2.125 seconds of wall time ("real"), 1.920 seconds of CPU time ("user"), and 0.170 seconds were spent in kernel mode ("sys"). The remaining 0.035 seconds were time sliced to other processes. (Make note that compressing a file is an intensive process that demands a lot of CPU time from the server.)

On the other side of the coin, there are some processes that require a lot of wall time, however they require very little CPU time.

This next example shows the processing time to run 'find' on the HC01 server's /big/dom tree:
$ time find /big/dom -ls
real 0m37.707s
user 0m1.210s
sys 0m1.260s

The difference in wall and CPU time is rather large for this task - clocking in at 35.237 seconds - which was time sliced out to other processes. The reason being is because of the time it takes to print over 50,000 files to the screen, therefore the Linux Kernel's scheduler was free to give more time slices to other processes. The extra 'user' and 'sys' times for this, in comparison to the next example, were taken up by the processing overhead that it takes for the 'printf()' function to output text to a display.

This example will remove the delay caused by outputting this file list to the screen:
$ time find /big/dom -ls > /dev/null
real 0m1.164s
user 0m0.900s
sys 0m0.260s

Now there is only a wall and CPU time difference of 0.004 seconds.

In short, there is no cut-and-dried rule for how the CPU time for a process will be sliced as it mostly depends on the processing requirements of the task and also how many other processes are vying for the CPU's attention. 


*********************************************************************(clock_time/cpu_time_constant = execution time)**************************************************************************************

dif=(start_t-end_t)


execution_time=dif/CLOCKS_PER_SEC

CLOCKS_PER_SEC -> IS A CONTSTANT VALUE WHICH DEPEND OF DIFFERENT OS AND CPU PERFORMENCE

**********************************************************************************************************************************************************************************************************
