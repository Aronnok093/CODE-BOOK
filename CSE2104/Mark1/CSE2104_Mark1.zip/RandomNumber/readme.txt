﻿Random Number:
int rand(void): returns a pseudo-random number in the range of [0, RAND_MAX).RAND_MAX: is a constant whose default value may vary \ between implementations but it is granted to be at least 32767.
We can print in a range using this metheod:
Cout<<min_value+rand()%max_value

