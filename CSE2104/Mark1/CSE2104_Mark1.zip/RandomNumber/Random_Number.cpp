#include<bits/stdc++.h>
using namespace std;

int main(){
    int mn,mx;
    FILE *fs = fopen("output.txt","w+");
    cin>>mn>>mx;
    int tmp=mx/2;
    srand(time(0));
    for(int i=0;i<=mx;i++){
        for(int j=0;j<=tmp;j++)
            fprintf(fs,"%d ",mn+rand()%mx);
        fprintf(fs,"\n");
    }
    fclose(fs);
    return 0;
}
