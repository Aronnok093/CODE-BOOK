#include<bits/stdc++.h>
using namespace std;

void write(int arr[],int siz);

void swp(int *a,int *b){  //pass by pointer
    int temp;             // c++ support "pass by value", "pass by reference", "pass by pointer"
    temp=*a;              // c support "pass by value" , "pass by pointer"
    *a=*b;                // pass by pointer vs pass by reference https://www.geeksforgeeks.org/passing-by-pointer-vs-passing-by-reference-in-c/
    *b=temp;
}

void srt(int arr[],int siz){
    bool flag;
    for(int i=0;i<siz;i++){
        flag=false;
        for(int j=0;j<siz-1-i;j++){
            if(arr[j]>arr[j+1]){
                swp(&arr[j],&arr[j+1]);
                flag=true;
            }
        }
        if(!flag)
            break;
    }
    write(arr,siz);
}

void write(int arr[],int siz){

    FILE *fs=fopen("output.txt","w+");
    fprintf(fs,"New Array After Bubble Sort \n");
    for(int i=0;i<siz;i++)
        fprintf(fs,"%d ",arr[i]);
    fprintf(fs,"\n");

    fclose(fs); //file must be close after read and wirte

}

int main(){
    int arr[]={1,3,2,7,5,6,9,10,8,4};
    int siz=sizeof(arr)/sizeof(arr[0]);
    srt(arr,siz);
    return 0;
}
