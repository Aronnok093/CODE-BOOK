/*
Lock a cell from an array then find a minimum value that is appropriate for that cell and swap its value with that lock cell value
Simple progress but time complexity O(n^2) which is same for both best and worst case.

During each iteration we will select the smallest item from the unsorted partition and move it to the sorted partition
*/

#include<bits/stdc++.h>
using namespace std;

void write(int arr[],int siz);


void swp(int *a,int *b){              // pass by pointer
    int temp;
    temp=*a;                         //pass by pointer vs pass by reference https://www.geeksforgeeks.org/passing-by-pointer-vs-passing-by-reference-in-c/
    *a=*b;
    *b=temp;
}

void srt(int arr[],int siz){
    for(int i=0;i<siz;i++){
        int lock_cell=i;
        int mn=i;                                 //let min value i bc we dont know what is the smallest value;
        for(int j=i+1;j<siz;j++){
            if(arr[j]<arr[mn])
                mn=j;

        }
        if(mn!=i)
            swp(&arr[lock_cell],&arr[mn]);
    }

    write(arr,siz);

}
void write(int arr[],int siz){

    FILE *fs=fopen("output.txt","w+");
    fprintf(fs,"New Array After Selection Sort \n");
    for(int i=0;i<siz;i++)
        fprintf(fs,"%d ",arr[i]);
    fprintf(fs,"\n");

    fclose(fs); //file must be close after read and wirte

}

int main(){
    int arr[]={1,3,2,7,5,6,9,10,8,4};
    int siz=sizeof(arr)/sizeof(arr[0]);
    srt(arr,siz);
    return 0;


}
